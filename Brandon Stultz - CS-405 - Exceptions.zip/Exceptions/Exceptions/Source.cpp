// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <exception>
#include <vector>

bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception
    std::vector<int> testVector(10);

    //throws an invalid vector error
    try {
        
        testVector.at(20) = 100;
    }
    catch (std::exception e) {
        std::cout << "ERROR: " << e.what() << '\n';
        return false;
    }

    return true;
}
void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing

    //thows error from above method
    std::cout << "Running Custom Application Logic." << std::endl;
    try {
        do_even_more_custom_application_logic();
    }
    catch(std::exception e){
        std::cout << "ERROR: " << e.what() << std::endl;
    }
}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception

    //Exception Block
    try{
        if (den == 0.0f) {                 //Throws error if denominator value is 0
            throw den;
        }                                                   
        else {
            return(num / den);          //Code runs returns divison of inputs if denominator doesnt not equal 0
        }
    }
    catch (float error) {
        std::cout << "ERROR: Divide by Zero Operation found" << std::endl;;  // If error is thown, function will retun null value
        return NULL;
    }
}

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.

    float numerator = 10.0f;
    float denominator = 0;

    //error catches the attempt to call the divide with zero as denominator
    try {
        auto result = divide(numerator, denominator);

        if (result == NULL) {
            throw result;
        }
        else {
            std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
        }
    }
    catch(...){
        std::cout << "ERROR: Call made to divide by zero" << std::endl;;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception 
    //  that wraps the whole main function, and displays a message to the console.
    //do_division();
    do_division();
    do_custom_application_logic();
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu